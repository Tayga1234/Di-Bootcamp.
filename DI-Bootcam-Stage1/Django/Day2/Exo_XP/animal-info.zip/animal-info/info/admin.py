from django.contrib import admin

from info.models import Animal, Famille

# Register your models here.
admin.site.register (Animal)
admin.site.register (Famille)